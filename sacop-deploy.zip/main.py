
from flask import Flask, request, jsonify
import openai
import requests
import time

app = Flask(__name__)
openai.api_key = "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"

ASSISTANT_ID = "asst_H5NZwsmNTzRHfUtqXiGfhywP"
WORDPRESS_API = "https://sacop.ai/wp-json/sacop/v1/search/"

@app.route("/")
def home():
    return "Sacop Assistant Backend is running."

@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json.get("message")
    if not user_input:
        return jsonify({"error": "No message provided"}), 400

    thread = openai.beta.threads.create()
    openai.beta.threads.messages.create(
        thread_id=thread.id,
        role="user",
        content=user_input
    )

    run = openai.beta.threads.runs.create(
        thread_id=thread.id,
        assistant_id=ASSISTANT_ID
    )

    status = run.status
    while status not in ["completed", "failed", "cancelled"]:
        time.sleep(2)
        run = openai.beta.threads.runs.retrieve(thread_id=thread.id, run_id=run.id)
        status = run.status

    if status != "completed":
        return jsonify({"error": f"Run failed with status: {status}"}), 500

    messages = openai.beta.threads.messages.list(thread_id=thread.id)
    tool_calls = []
    for m in messages.data:
        if m.role == "assistant" and m.tool_calls:
            tool_calls = m.tool_calls
            break

    tool_outputs = []
    for call in tool_calls:
        if call.function.name == "search_products":
            query = eval(call.function.arguments).get("query")
            wp_res = requests.get(WORDPRESS_API, params={"query": query})
            if wp_res.status_code == 200:
                tool_outputs.append({
                    "tool_call_id": call.id,
                    "output": {"success": "true", "results": wp_res.json()}
                })

    if tool_outputs:
        run = openai.beta.threads.runs.submit_tool_outputs(
            thread_id=thread.id,
            run_id=run.id,
            tool_outputs=tool_outputs
        )
        while run.status not in ["completed", "failed"]:
            time.sleep(2)
            run = openai.beta.threads.runs.retrieve(thread_id=thread.id, run_id=run.id)

    messages = openai.beta.threads.messages.list(thread_id=thread.id)
    reply = next((m.content[0].text.value for m in messages.data if m.role == "assistant"), "No response.")
    return jsonify({"reply": reply})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)
